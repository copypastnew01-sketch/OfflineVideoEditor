package com.example.offlinevideoeditor;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.media.MediaMetadataRetriever;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ExportException;
import androidx.media3.effect.RgbFilter;
import androidx.media3.effect.ScaleAndRotateTransformation;
import androidx.media3.effect.HslAdjustment;
import androidx.media3.effect.SpeedChangeEffect;
import androidx.media3.effect.GlEffect;
import androidx.media3.transformer.Composition;
import androidx.media3.common.audio.SonicAudioProcessor;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.google.common.collect.ImmutableList;

public class MainActivity extends AppCompatActivity {
    private Uri inputUri;
    private Spinner speedSpinner, filterSpinner, resolutionSpinner;
    private CheckBox flipBox;
    private TextView status;
    private ProgressBar progress;
    private ActivityResultLauncher<Intent> picker;
    private ActivityResultLauncher<String[]> permissionLauncher;

    @Override public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        permissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> openPicker());
        picker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                inputUri = result.getData().getData();
                status.setText("Video selected ✓");
            }
        });
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,28);
        ScrollView scroll = new ScrollView(this); scroll.addView(root);
        TextView title = new TextView(this); title.setText("Offline Video Editor"); title.setTextSize(26); title.setGravity(Gravity.CENTER); title.setPadding(0,10,0,24); root.addView(title);
        Button select = new Button(this); select.setText("Select Video"); root.addView(select); select.setOnClickListener(v -> chooseVideo());
        speedSpinner = addSpinner(root,"Speed",new String[]{"0.5×","0.75×","1.0×","1.1×","1.2×","1.3×","1.5×","2.0×","3.0×","4.0×"});
        filterSpinner = addSpinner(root,"Filter",new String[]{"Normal","Dreamy Mood","Story Filter","Black & White"});
        resolutionSpinner = addSpinner(root,"Export",new String[]{"720p HD","1080p Full HD"});
        flipBox = new CheckBox(this); flipBox.setText("Flip horizontally"); root.addView(flipBox);
        Button export = new Button(this); export.setText("Export Video"); root.addView(export);
        progress = new ProgressBar(this); progress.setVisibility(View.GONE); root.addView(progress);
        status = new TextView(this); status.setText("Ready — select a video"); status.setTextSize(16); status.setPadding(0,24,0,10); root.addView(status);
        TextView note = new TextView(this); note.setText("H.264 video + AAC audio • Offline processing • Saves to Movies/OfflineVideoEditor"); root.addView(note);
        export.setOnClickListener(v -> startExport());
        setContentView(scroll);
    }

    private Spinner addSpinner(LinearLayout root,String label,String[] items){
        TextView t=new TextView(this); t.setText(label); t.setPadding(0,18,0,4); root.addView(t);
        Spinner s=new Spinner(this); ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,items); s.setAdapter(a); root.addView(s); return s;
    }

    private void chooseVideo(){
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) { permissionLauncher.launch(new String[]{Manifest.permission.READ_MEDIA_VIDEO}); return; }
        } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) { permissionLauncher.launch(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}); return; }
        openPicker();
    }
    private void openPicker(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); picker.launch(i); }

    private float getSpeed(){ return new float[]{0.5f,0.75f,1f,1.1f,1.2f,1.3f,1.5f,2f,3f,4f}[speedSpinner.getSelectedItemPosition()]; }

    private void startExport(){
        if(inputUri==null){Toast.makeText(this,"Pehle video select karo",Toast.LENGTH_SHORT).show();return;}
        progress.setVisibility(View.VISIBLE); status.setText("Processing… phone par video process ho rahi hai");
        try {
            float speed=getSpeed();
            ArrayList<GlEffect> videoEffects=new ArrayList<>();
            String filter=(String)filterSpinner.getSelectedItem();
            if("Black & White".equals(filter)) videoEffects.add(RgbFilter.createGrayscaleFilter());
            else if("Dreamy Mood".equals(filter)) { videoEffects.add(new HslAdjustment.Builder().setSaturation(0.15f).setLightness(0.08f).build()); }
            else if("Story Filter".equals(filter)) { videoEffects.add(new HslAdjustment.Builder().setSaturation(0.22f).setLightness(0.02f).build()); }
            // Resolve the requested HD size from the source dimensions without loading the whole video into RAM.
            MediaMetadataRetriever mmr = new MediaMetadataRetriever();
            mmr.setDataSource(this, inputUri);
            int srcW = Integer.parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
            int srcH = Integer.parseInt(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            mmr.release();
            int targetH = resolutionSpinner.getSelectedItemPosition() == 0 ? 720 : 1080;
            float scale;
            if (srcW >= srcH) scale = targetH / (float) srcH;
            else scale = targetH / (float) srcW;
            float sx = flipBox.isChecked() ? -scale : scale;
            float sy = scale;
            videoEffects.add(new ScaleAndRotateTransformation.Builder().setScale(sx,sy).build());
            videoEffects.add(new SpeedChangeEffect(speed));
            SonicAudioProcessor sonic=new SonicAudioProcessor(); sonic.setSpeed(speed); sonic.setPitch(1f);
            EditedMediaItem edited=new EditedMediaItem.Builder(MediaItem.fromUri(inputUri)).setEffects(new Effects(ImmutableList.of(sonic),ImmutableList.copyOf(videoEffects))).build();
            String name="Edited_"+System.currentTimeMillis()+".mp4";
            ContentValues values=new ContentValues(); values.put(MediaStore.Video.Media.DISPLAY_NAME,name); values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4"); values.put(MediaStore.Video.Media.RELATIVE_PATH,Environment.DIRECTORY_MOVIES+"/OfflineVideoEditor"); if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.Video.Media.IS_PENDING,1);
            Uri out=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values); if(out==null) throw new IOException("Gallery output create failed");
            File temp=new File(getCacheDir(),name); 
            Transformer transformer=new Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC).addListener(new Transformer.Listener(){
                @Override public void onCompleted(Composition c, ExportResult r){
                    try(java.io.InputStream in=new java.io.FileInputStream(temp); java.io.OutputStream os=getContentResolver().openOutputStream(out)) { byte[] b=new byte[8192]; int n; while((n=in.read(b))>0) os.write(b,0,n); }
                    catch(Exception e){ getContentResolver().delete(out,null,null); runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Save error: "+e.getMessage());}); return; }
                    if(Build.VERSION.SDK_INT>=29){ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(out,done,null,null);} temp.delete(); runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Done ✓ Saved in Movies/OfflineVideoEditor");});
                }
                @Override public void onError(Composition c, ExportResult r, ExportException e){ runOnUiThread(()->{progress.setVisibility(View.GONE);status.setText("Export failed: "+e.getMessage());}); }
            }).build();
            transformer.start(edited,temp.getAbsolutePath());
        } catch(Exception e){ progress.setVisibility(View.GONE); status.setText("Error: "+e.getMessage()); }
    }
}
