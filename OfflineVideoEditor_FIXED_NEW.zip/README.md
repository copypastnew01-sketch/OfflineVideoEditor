# OfflineVideoEditor

Mobile-friendly Android video editor project.

Features: video select, speed 0.5x-4x including 1.3x, Dreamy Mood, Story Filter, Black & White, 720p/1080p export choices, H.264/AAC, Gallery save to Movies/OfflineVideoEditor, offline media processing, horizontal flip.

Build on GitHub Actions: Actions > Build APK > Run workflow. The workflow intentionally uses installed Gradle 8.7, so it does NOT depend on a missing gradlew file.
